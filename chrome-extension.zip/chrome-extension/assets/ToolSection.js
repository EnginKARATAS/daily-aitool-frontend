import{o as t,t as a}from"./index.js";const r={__name:"ToolSection",props:["modelValue"],setup(o){const e=o;return t(()=>{console.log(e.modelValue)}),(l,n)=>a(o.modelValue)}};export{r as default};
